```python
# Importamos las bibliotecas necesarias
```


```python
!pip install pandas
!pip install matplotlib
```

    Requirement already satisfied: pandas in c:\users\rachel sierra\miniconda3\lib\site-packages (2.1.1)
    Requirement already satisfied: numpy>=1.23.2 in c:\users\rachel sierra\miniconda3\lib\site-packages (from pandas) (1.26.0)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\rachel sierra\miniconda3\lib\site-packages (from pandas) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\rachel sierra\miniconda3\lib\site-packages (from pandas) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in c:\users\rachel sierra\miniconda3\lib\site-packages (from pandas) (2023.3)
    Requirement already satisfied: six>=1.5 in c:\users\rachel sierra\miniconda3\lib\site-packages (from python-dateutil>=2.8.2->pandas) (1.16.0)
    Requirement already satisfied: matplotlib in c:\users\rachel sierra\miniconda3\lib\site-packages (3.7.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (1.0.5)
    Requirement already satisfied: cycler>=0.10 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (1.4.4)
    Requirement already satisfied: numpy>=1.20 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (1.26.0)
    Requirement already satisfied: packaging>=20.0 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (23.0)
    Requirement already satisfied: pillow>=6.2.0 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (10.0.1)
    Requirement already satisfied: pyparsing<3.1,>=2.3.1 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\rachel sierra\miniconda3\lib\site-packages (from matplotlib) (2.8.2)
    Requirement already satisfied: six>=1.5 in c:\users\rachel sierra\miniconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    


```python
import pandas as pd
import requests
from io import StringIO
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
```


```python
# Cargamos los datos desde el repositorio de GitHub
```


```python
url = 'https://raw.githubusercontent.com/cienciadedatos/datos-de-miercoles/master/datos/2019/2019-04-10/partidos.txt'
response = requests.get(url)
data = response.text
df = pd.read_csv(StringIO(data), sep='\t')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>anio</th>
      <th>anfitrion</th>
      <th>estadio</th>
      <th>ciudad</th>
      <th>partido_orden</th>
      <th>fecha</th>
      <th>equipo_1</th>
      <th>equipo_2</th>
      <th>equipo_1_final</th>
      <th>equipo_2_final</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1930</td>
      <td>Uruguay</td>
      <td>Estadio Pocitos</td>
      <td>Montevideo</td>
      <td>(1)</td>
      <td>1930-07-13</td>
      <td>Francia</td>
      <td>Mexico</td>
      <td>4</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1930</td>
      <td>Uruguay</td>
      <td>Estadio Parque Central</td>
      <td>Montevideo</td>
      <td>(2)</td>
      <td>1930-07-13</td>
      <td>Estados Unidos</td>
      <td>Bélgica</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1930</td>
      <td>Uruguay</td>
      <td>Estadio Parque Central</td>
      <td>Montevideo</td>
      <td>(3)</td>
      <td>1930-07-14</td>
      <td>Yugoslavia</td>
      <td>Brasil</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1930</td>
      <td>Uruguay</td>
      <td>Estadio Pocitos</td>
      <td>Montevideo</td>
      <td>(4)</td>
      <td>1930-07-14</td>
      <td>Rumania</td>
      <td>Perú</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1930</td>
      <td>Uruguay</td>
      <td>Estadio Parque Central</td>
      <td>Montevideo</td>
      <td>(5)</td>
      <td>1930-07-15</td>
      <td>Argentina</td>
      <td>Francia</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>895</th>
      <td>2018</td>
      <td>Rusia</td>
      <td>Samara Arena</td>
      <td>Samara (UTC+4)</td>
      <td>(60)</td>
      <td>2018-07-07</td>
      <td>Suecia</td>
      <td>Inglaterra</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>896</th>
      <td>2018</td>
      <td>Rusia</td>
      <td>Saint Petersburg Stadium</td>
      <td>St. Petersburg (UTC+3)</td>
      <td>(61)</td>
      <td>2018-07-10</td>
      <td>Francia</td>
      <td>Bélgica</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>897</th>
      <td>2018</td>
      <td>Rusia</td>
      <td>Luzhniki Stadium</td>
      <td>Moscow (UTC+3)</td>
      <td>(62)</td>
      <td>2018-07-11</td>
      <td>Croacia</td>
      <td>Inglaterra</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>898</th>
      <td>2018</td>
      <td>Rusia</td>
      <td>Saint Petersburg Stadium</td>
      <td>St. Petersburg (UTC+3)</td>
      <td>(63)</td>
      <td>2018-07-14</td>
      <td>Bélgica</td>
      <td>Inglaterra</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>899</th>
      <td>2018</td>
      <td>Rusia</td>
      <td>Luzhniki Stadium</td>
      <td>Moscow (UTC+3)</td>
      <td>(64)</td>
      <td>2018-07-15</td>
      <td>Francia</td>
      <td>Croacia</td>
      <td>4</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>900 rows × 10 columns</p>
</div>




```python
#Crear dos gráficos en el que comparen a al menos dos países diferentes. Si quieren incluir a más países pueden hacerlo.
#Gráfico 1 deberá ser un gráfico en el que los datos de los países comparados aparezcan en el mismo cuadro
```


```python
pais = df['anfitrion'].drop_duplicates()
print(pais)
```

    0                    Uruguay
    18                    Italia
    35                   Francia
    53                    Brasil
    75                     Suiza
    101                   Suecia
    136                    Chile
    168               Inglaterra
    200                   Mexico
    232      Alemania occidental
    270                Argentina
    308                   España
    464           Estados Unidos
    580    Corea del sur y Japón
    644                 Alemania
    708                Sudáfrica
    836                    Rusia
    Name: anfitrion, dtype: object
    


```python
df_anio_pais = df[['anio','anfitrion']].drop_duplicates()
print(df_anio_pais)
```

         anio              anfitrion
    0    1930                Uruguay
    18   1934                 Italia
    35   1938                Francia
    53   1950                 Brasil
    75   1954                  Suiza
    101  1958                 Suecia
    136  1962                  Chile
    168  1966             Inglaterra
    200  1970                 Mexico
    232  1974    Alemania occidental
    270  1978              Argentina
    308  1982                 España
    360  1986                 Mexico
    412  1990                 Italia
    464  1994         Estados Unidos
    516  1998                Francia
    580  2002  Corea del sur y Japón
    644  2006               Alemania
    708  2010              Sudáfrica
    772  2014                 Brasil
    836  2018                  Rusia
    


```python
# Contar la cantidad de veces que cada país ha sido anfitrión
counts = df_anio_pais ['anfitrion'].value_counts()
print(counts)
```

    anfitrion
    Mexico                   2
    Francia                  2
    Brasil                   2
    Italia                   2
    Argentina                1
    Sudáfrica                1
    Alemania                 1
    Corea del sur y Japón    1
    Estados Unidos           1
    España                   1
    Uruguay                  1
    Alemania occidental      1
    Inglaterra               1
    Chile                    1
    Suecia                   1
    Suiza                    1
    Rusia                    1
    Name: count, dtype: int64
    


```python
# Gráfico de barras con colores asignados en función de la cantidad de veces que el país ha sido anfitrión
fig, ax = plt.subplots()
ax.bar(counts.index, counts.values, color=plt.cm.get_cmap('YlOrRd')(np.linspace(0.2, 1, len(counts.index))))
ax.set_xticklabels(counts.index, rotation=90)
ax.set_title('Cantidad de veces que cada país ha sido anfitrión')
ax.set_xlabel('País')
ax.set_ylabel('Cantidad')
plt.show()
```

    C:\Users\Rachel Sierra\AppData\Local\Temp\ipykernel_10940\1490139871.py:3: MatplotlibDeprecationWarning: The get_cmap function was deprecated in Matplotlib 3.7 and will be removed two minor releases later. Use ``matplotlib.colormaps[name]`` or ``matplotlib.colormaps.get_cmap(obj)`` instead.
      ax.bar(counts.index, counts.values, color=plt.cm.get_cmap('YlOrRd')(np.linspace(0.2, 1, len(counts.index))))
    C:\Users\Rachel Sierra\AppData\Local\Temp\ipykernel_10940\1490139871.py:4: UserWarning: FixedFormatter should only be used together with FixedLocator
      ax.set_xticklabels(counts.index, rotation=90)
    


    
![png](output_9_1.png)
    



```python
#Para el primer gráfico he escogido todos los paises, de los mismos he identificado que Mexico, Francia,Brasil e Italio han sido anfitriones en dos (2) ocasiones en un mundial de futbol masculio, mientras que todos los demás paises han sido anfitriones una sola vez.
```


```python
#Gráfico 2 deberá ser un gráfico en el que los datos de cada país aparezca en un subgráfico diferente. Es decir, una figura tenga al menos dos recuadros (uno por cada país en la comparación).
```


```python
fig, axs = plt.subplots(nrows=len(counts.index), figsize=(2, 20))
for i, country in enumerate(counts.index):
    data = counts[country]
    axs[i].bar([country], [data], color=plt.cm.get_cmap('YlOrRd')(data / counts.max()))
    axs[i].set_title(country)
    axs[i].set_xlabel('País')
    axs[i].set_ylabel('Cantidad')
    axs[i].set_title('Cantidad de veces que '+country+' ha sido anfitrión')

plt.tight_layout()
plt.show()
```

    C:\Users\Rachel Sierra\AppData\Local\Temp\ipykernel_10940\1622054271.py:4: MatplotlibDeprecationWarning: The get_cmap function was deprecated in Matplotlib 3.7 and will be removed two minor releases later. Use ``matplotlib.colormaps[name]`` or ``matplotlib.colormaps.get_cmap(obj)`` instead.
      axs[i].bar([country], [data], color=plt.cm.get_cmap('YlOrRd')(data / counts.max()))
    


    
![png](output_12_1.png)
    



```python
#A continuación el siguiente grafico nos indica que todos los paises marcados con color rojo y que muentran en cantidad dos (2) han sido dos veces anfitriones del mundial de futbol masculinoñ mientras que los paises en tomate nos indican que han sido anfitriones una sola vez.
```


```python
#A continuación, realizaremos un análisis de que equipos ganaron más partidos dentro de los mundiales de futbol (1930-2018)
```


```python
# Crearemos una nueva columna para identificar el ganador
df['ganador'] = df.apply(lambda row: row['equipo_1'] if row['equipo_1_final'] > row['equipo_2_final'] else row['equipo_2'], axis=1)
```


```python
# Ahora contaremos las victorias de cada equipo
victorias = df['ganador'].value_counts()
print(victorias)
```

    ganador
    Brasil                  82
    Argentina               52
    Italia                  51
    Alemania occidental     43
    Francia                 41
                            ..
    Republica de Irlanda     1
    Israel                   1
    Jamaica                  1
    Bolivia                  1
    Islandia                 1
    Name: count, Length: 73, dtype: int64
    


```python
# A continuación, crearemos un gráfico de barras con los resultados de los paises con más victorias
victorias.plot(kind='bar')
plt.xlabel('Equipos')
plt.ylabel('Victorias')
plt.title('Número de victorias por equipo')
plt.show()
```


    
![png](output_17_0.png)
    



```python
# Debido a que el gráfico es muy extenso y poco visible, ordenaremos las victorias y seleccionaremos el top 10
victorias_ordenadas = victorias.sort_values(ascending=False)
top_10 = victorias_ordenadas[:10]
```


```python
# Asi tambien, crearemos una lista de colores para nuestro gráfico
colores = cm.viridis(np.linspace(0, 1, 10))
```


```python
# Y por último, crearemos un gráfico de barras con los resultados
top_10.plot(kind='bar', color=colores)
plt.xlabel('Equipos')
plt.ylabel('Victorias')
plt.title('Top 10 equipos con más victorias')
plt.show()
```


    
![png](output_20_0.png)
    



```python
#Para finalizar, analizaremos y graficaremos la cantidad de goles marcados por equipos en el historico de mundiales de futbol masculino.
```


```python
# Primero, calculamos la cantidad total de goles por equipo
goles_equipo_1 = df.groupby('equipo_1')['equipo_1_final'].sum()
goles_equipo_2 = df.groupby('equipo_2')['equipo_2_final'].sum()
```


```python
# Sumamos los goles de ambos equipos
goles_totales = goles_equipo_1.add(goles_equipo_2, fill_value=0)
print(goles_totales)
```

    Alemania                91.0
    Alemania del Este        5.0
    Alemania occidental    140.0
    Angola                   0.0
    Arabia Saudita           9.0
                           ...  
    Ucrania                  8.0
    Unión Soviética         53.0
    Uruguay                 90.0
    Yugoslavia              62.0
    Zaire                    0.0
    Length: 85, dtype: float64
    


```python
# Creamos el gráfico
plt.figure(figsize=(20,40))
goles_totales.sort_values().plot(kind='barh', color='skyblue')
plt.xlabel('Cantidad de Goles')
plt.ylabel('Equipos')
plt.title('Cantidad de Goles por Equipo')
plt.show()
```


    
![png](output_24_0.png)
    



```python
# Ordenamos los equipos por la cantidad total de goles y seleccionamos el top 10
top_10_equipos = goles_totales.sort_values(ascending=False).head(10)
```


```python
# Creamos un gráfico circular para los 10 equipos con más goles
plt.figure(figsize=(15,10))
plt.pie(top_10_equipos, labels=top_10_equipos.index, autopct='%1.1f%%')
plt.title('Distribución de Goles de los 10 Equipos con Más Goles')
plt.savefig('distribucion_goles_equipos_top_ten.png')
plt.show()
```


    
![png](output_26_0.png)
    



```python
#A continuación se procedio a guardar el grafico de 'Distribución de Goles de los 10 Equipos con Más Goles
plt.savefig('distribucion_goles_equipos_top_ten.png')
```
